import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privatechat',
  templateUrl: './privatechat.component.html',
  styleUrls: ['./privatechat.component.css']
})
export class PrivatechatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
